const dbConsts= {
    dbUri: process.env.DB_URI,
    dbName: process.env.DB_NAME
}

module.exports = dbConsts;