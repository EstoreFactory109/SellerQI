const credentials={
    clientId : process.env.SPAPI_CLIENT_ID,
    clientSecret : process.env.SPAPI_CLIENT_SECRET
}

module.exports=credentials;