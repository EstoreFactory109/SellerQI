const {generateSPAPITokens,SaveAllDetails}=require('../controllers/TokenControllers');
const auth =require('../middlewares/Auth/auth.js')
const express=require('express');
const router=express.Router();

router.get('/generateSPAPITokens/:payload',auth,generateSPAPITokens);
router.post('/SaveAllDetails',auth,SaveAllDetails);


module.exports=router;