import React from 'react'

const AccountIntegrations = () => {
  return (
    <div>AccountIntegrations</div>
  )
}

export default AccountIntegrations