import React from 'react'

const ProfilePic = () => {
  return (
    <div>ProfilePic</div>
  )
}

export default ProfilePic