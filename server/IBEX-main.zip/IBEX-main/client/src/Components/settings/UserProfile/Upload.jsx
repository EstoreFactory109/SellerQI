import React from 'react'

const Upload = () => {
  return (
    <div>Upload</div>
  )
}

export default Upload