import React from 'react'

const TrafficStats = () => {
  return (
    <div>TrafficStats</div>
  )
}

export default TrafficStats